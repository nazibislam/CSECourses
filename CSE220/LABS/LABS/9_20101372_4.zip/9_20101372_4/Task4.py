from queue import PriorityQueue
import math


inputFile=open("G:\\New folder\\LABS\\Lab04\\input4.txt","r")
outputFile=open("G:\\New folder\\LABS\\Lab04\\output4.txt","w")
inp=(inputFile.readline())



def Network(Graph, source):
    dist = [-math.inf]*(len(Graph)+1)
    dist[source] = math.inf
    Q = PriorityQueue()
    visited = [False]*(len(Graph)+1)
    for v in Graph:
        Q.put((-dist[v],v))
    while not Q.empty():
        u = Q.get()[-1]       
        if visited[u]:
            continue
        visited[u] = True
        
        for v in Graph[u]:
            alt = min(dist[u],v[1])
            if alt>dist[v[0]]:
                dist[v[0]] = alt
                Q.put((-dist[v[0]],v[0]))
    for i in range(1,len(Graph)):
        if(dist[i]==-math.inf):
            dist[i]=-1
    dist[source]=0  
    print((dist[1:]),file=outputFile)
   
for i in range(int(inp)):
    adjlst={}
    lst1=inputFile.readline().split()
    places=int(lst1[0])
    roads=int(lst1[1])
    for i in range(1,places+1):
        adjlst[i]=[]
    for j in range(roads):
        lst2=inputFile.readline().split()
        u=int(lst2[0])
        v=int(lst2[1])
        w=int(lst2[2])
        adjlst[u].append([v,w])
    source=int(inputFile.readline())
    Network(adjlst,source)
    
