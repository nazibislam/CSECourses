from queue import PriorityQueue
import math

inputFile=open("G:\\New folder\\LABS\\Lab04\\input2.txt","r")
outputFile=open("G:\\New folder\\LABS\\Lab04\\output2.txt","w")
inp=int(inputFile.readline())

def Dijkstra(Graph, source):
    dist = [math.inf]*len(Graph)
    prev = [None]*len(Graph)
    dist[source] = 0
    Q = PriorityQueue()
    visited = [False]*len(Graph)
    Q.put((dist[source], source))
    for v in Graph:
        if(v!=source):
            dist[v]=math.inf
            prev[v]=None
        Q.put((dist[source],source))
        visited[v]=False
    while not Q.empty():
        u = Q.get()[1]
        if visited[u]:
            continue
        visited[u] = True
        for v in Graph[u]:
            alt = dist[u] + v[1]
            if alt<dist[v[0]]:
                dist[v[0]] = alt
                prev[v[0]]=u
                Q.put((dist[v[0]],v[0]))
    min_titan=[]
    i=len(prev)-1
    while(True):
        if(prev[i]==None):
            min_titan.append(1)
            break
        min_titan.append(i)
        i=prev[i]
    min_titan.reverse()
    print(min_titan, file=outputFile)
  



for i in range(0,inp):
    adjlst={}
    lst1=inputFile.readline().split()
    places=int(lst1[0])
    roads=int(lst1[1])
    for i in range(places+1):
        adjlst[i]=[]
    for j in range(roads):
        lst2=inputFile.readline().split()
        u=int(lst2[0])
        v=int(lst2[1])
        w=int(lst2[2])
        adjlst[u].append([v,w])
    Dijkstra(adjlst,1) 

