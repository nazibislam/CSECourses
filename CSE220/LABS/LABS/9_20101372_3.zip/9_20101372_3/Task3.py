input_file=open("G:\\New folder\\LABS\\Lab03\\input.txt")
inp=input_file.read().split('\n')
dic={}
for i in range(1,len(inp)):
    store=inp[i]
    spl=store.split()
    k=int(spl[0])
    lst=[]
    for j in range(1,len(spl)):
        lst.append(int(spl[j]))
    dic[k]=lst

for i in dic:
    print(str(i)+">"+str(dic[i]))

visited=[0]*12
printed=[]
def DFS_VISIT(graph,node):
    visited[int(node)-1]=1
    printed.append(node)
    for i in graph[node]:
        if i not in visited:
            DFS_VISIT(graph,i)

def DFS(graph,endPoint):
    for i in graph:
        if i not in visited:
            DFS_VISIT(graph,i)
    for i in printed:
        print(i, end=' ')
        if i==endPoint:
            break
DFS(dic,12)
