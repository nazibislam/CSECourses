input_file=open("G:\\New folder\\LABS\\Lab03\\input.txt")
inp=input_file.read().split('\n')
dic={}
for i in range(1,len(inp)-1):
    store=inp[i]
    spl=store.split()
    k=int(spl[0])
    lst=[]
    for j in range(1,len(spl)):
        lst.append(int(spl[j]))
    dic[k]=lst

for i in dic:
    print(str(i)+">"+str(dic[i]))


visited=[0]*12
queue=[]
def BFS(visited,graph,node,endPoint):
    visited[int(node)-1]=1
    queue.append(node)
    while queue:
        m=queue.pop(0)
        print(str(m),end=' ')
        if m==endPoint:
            break
        for neighbour in graph[m]:
            if visited[int(neighbour)-1]==0:
                visited[int(neighbour)-1]=1
                queue.append(neighbour)
BFS(visited,dic,1,12)

