input_file=open("G:\\New folder\\LABS\\Lab03\\input.txt")
inp=input_file.read().split('\n')
dic={}
for i in range(1,len(inp)):
    store=inp[i]
    spl=store.split()
    k=int(spl[0])
    lst=[]
    for j in range(1,len(spl)):
        lst.append(int(spl[j]))
    dic[k]=lst

for i in dic:
    print(str(i)+">"+str(dic[i]))


    
