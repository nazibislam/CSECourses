fi=open('G:\\New folder\\test\\input3.txt','r')
fo=open('G:\\New folder\\test\\output3.txt','w')
ro=fi.read().split()
n=int(ro[0])

A=[]
for i in range(1,n+1):
    A.append(ro[i])
    
B=[]
for i in range(n+1,len(ro)):
    B.append(ro[i])

for i in range(1, len(B)):
    temp = B[i]
    temp2=A[i]
    j = i-1
    while j >=0 and  B[j]<temp :
            A[j+1]=A[j]
            B[j+1] = B[j]          
            j -= 1           
    B[j+1] =temp
    A[j+1]=temp2

for i in range(len(A)):
    fo.write(str(A[i]))
    fo.write(' ')
