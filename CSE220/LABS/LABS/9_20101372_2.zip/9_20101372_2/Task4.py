fi=open('G:\\New folder\\test\\input4.txt','r')
fo=open('G:\\New folder\\test\\output4.txt','w')
ro=fi.read().split()
n=ro[0]

arr=[]
for i in range(1,len(ro)):
    arr.append(int(ro[i]))

def merge(L,R):
    A=[]
    i=0
    j=0
    while i<len(L) and j<len(R):
        if (L[i]<R[j]):
            A.append(L[i])
            i+=1
        else:
            A.append(R[j])
            j+=1
    A+=L[i::]
    A+=R[j::]
    return A

def mergeSort(P):
    if(len(P)<=1):
        return P
    m=int(len(P)/2)
    L=mergeSort(P[:m])
    R=mergeSort(P[m:])
    return merge(L,R)

final=mergeSort(arr)

for i in range(len(final)):
    fo.write(str(final[i]))
    fo.write(' ')        



