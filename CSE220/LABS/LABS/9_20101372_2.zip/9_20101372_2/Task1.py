fi=open('G:\\New folder\\test\\input1.txt','r')
fo=open('G:\\New folder\\test\\output1.txt','w')
ro=fi.read().split()

def bubbleSort(r):
    n = int(ro[0])  
    for i in range(n):
        swapping = False        
        for j in range(1,n-i-1):           
            if ro[j] > ro[j+1] :
                ro[j], ro[j+1] = ro[j+1], ro[j]
                swapping = True        
        if swapping == False:
            break
#We see that for this scenerio, the best case scenerio is if the array is already sorted. So we don't have to sort the array again. That is why, the time complexity for the best case scenerio becomes Big Theta(n)

bubbleSort(ro)
for i in range(1,len(ro)):
    fo.write(str(ro[i]))
    fo.write(' ')
   
    

   
