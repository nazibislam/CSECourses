fi=open('G:\\New folder\\test\\input2.txt','r')
fo=open('G:\\New folder\\test\\output2.txt','w')
ro=fi.read().split()
n=int(ro[0])
A = []
for i in range(2,len(ro)):
    A.append(int(ro[i])) 


for i in range(len(A)):
        
    min_idx = i
    for j in range(i+1, len(A)):
        if A[min_idx] > A[j]:
            min_idx = j
             
     
    A[i], A[min_idx] = A[min_idx], A[i]


for i in range(0,int(ro[1])):
    fo.write(str(A[i]))
    fo.write(' ')
