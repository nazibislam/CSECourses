finput=open('G:\\New folder\\LABS\\input04.txt')
foutput=open('G:\\New folder\\LABS\\output04.txt')
sinput=finput.read().split()

dim = int(input("Enter the dimension: " ))

print("Enter the elements of First Matrix:")
A= [[int(input()) for i in range(dim)] for i in range(dim)]

print("Enter the elements of Second Matrix:")

B= [[int(input()) for i in range(dim)] for i in range(dim)]
    
C=[[0 for i in range(dim)] for i in range(dim)]

for i in range(len(A)):
    for j in range(len(B[0])):
        for k in range(len(B)):
            C [i][j]+=A[i][k]*B[k][j]

for r in C:
    print(r)
    foutput.write(str(r))