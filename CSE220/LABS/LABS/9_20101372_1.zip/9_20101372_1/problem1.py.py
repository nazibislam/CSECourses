finput=open('G:\\New folder\\LABS\\input.txt')
foutput=open('G:\\New folder\\LABS\\output.txt')
frecord=open('G:\\New folder\\LABS\\record.txt')
sinput=(finput.read().split('\n'))

count=len(sinput)
dcount=0
odd=0
even=0
palindromCount=0
nonpalindromCount=0

def palindromCheck(word):
   
    for i in range(len(sinput)):       
        number=palindromCheck(sinput[i].split(" ")[0])
        string=sinput[i].split(" ")[1]
        result=''
        if '.' in number:
            result+=str(number)+" cannot have parity and "
            dcount+=1

        elif(number%2==0):
            result+=str(number)+" has even parity and "
            even+=1
            
        else:
            result+=str(number)+" has odd parity and "
            odd+=1
        
        if(string == string[::-1]):
            result+=string+" is a palindrom"
            palindromCount+=1           
        else:
            result+=string+" is not a palindromt"
            nonpalindromCount+=1
        foutput.write(result)



odd=int((odd/count)*100)
even=int((even/count)*100)
dcount=int((dcount/count)*100)
palindromCount=int((palindromCount/count)*100)
nonpalindromCount=int((nonpalindromCount/count)*100)
frecord.write('Percentage of odd parity: '+str(odd)+'%'+'\n')
frecord.write('Percentage of even parity: '+str(even)+'%'+'\n')
frecord.write('Percentage of no parity: '+str(dcount)+'%'+'\n')
frecord.write('Percentage of palindromCount: '+str(palindromCount)+'%'+'\n')
frecord.write('Percentage of non-palindromCount: '+str(nonpalindromCount)+'%'+'\n')
