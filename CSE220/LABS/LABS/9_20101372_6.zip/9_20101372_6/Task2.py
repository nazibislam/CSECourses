finput=open("G:\\New folder\\LABS\\9_20101372_6\\input2.txt",'r')
foutput=open("G:\\New folder\\LABS\\9_20101372_6\\output2.txt",'w')
inp1= finput.readline()
inp2= finput.readline()
inp3= finput.readline()

def LCS(X,Y,Z):
    m = len(X) - 1
    n = len(Y) - 1
    o = len(Z) - 1

    lst = [[[None]*(o+1) for i in range(n+1)] for y in range(m+1)]

    for i in range(m + 1):
        for j in range(n + 1):
            for k in range(o + 1):

                if i == 0 or j == 0 or k == 0 :
                    lst[i][j][k] = 0

                elif X[i-1] == Y[j-1] == Z[k-1]:
                    lst[i][j][k] = lst[i-1][j-1][k-1] + 1

                else:
                    lst[i][j][k] = max(lst[i-1][j][k] , lst[i][j-1][k],lst[i][j][k-1])

    return lst[m][n][o]

length=LCS(inp1, inp2, inp3)
print(length,file=foutput)